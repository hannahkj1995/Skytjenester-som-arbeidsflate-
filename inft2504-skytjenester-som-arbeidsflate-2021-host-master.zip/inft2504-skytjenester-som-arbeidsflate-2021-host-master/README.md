# INFT2504 Skytjenester som arbeidsflate - 2021 HØST

Karaktertellende oppgaver i faget INFT2504 Skytjenester som arbeidsflate (2021 HØST). 